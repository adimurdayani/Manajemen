<!-- Required Js -->
<script src="<?= base_url()?>assets/js/vendor-all.min.js"></script>
<script src="<?= base_url()?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?= base_url()?>assets/js/ripple.js"></script>
<script src="<?= base_url()?>assets/js/pcoded.min.js"></script>

</body>

</html>